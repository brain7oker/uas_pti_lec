import React from 'react';


function Footer() {
  return (
    <div className="mt-5 bg-primary py-1">
      <p className="m-0 text-center text-white">Dashboard Covid © 2021</p>
    </div>
  );
}

export default Footer;