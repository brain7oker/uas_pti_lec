export const API_COVID19_GLOBAL = "https://covid19.mathdro.id/"
export const API_COVID19_INDO = "https://apicovid19indonesia-v2.vercel.app/"